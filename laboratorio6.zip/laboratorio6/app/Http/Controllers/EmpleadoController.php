<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use Illuminate\Http\Request;

class EmpleadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datos['empleados']=Empleado::paginate(10);
        return view ('empleado.index', $datos);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('empleado.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validar los datos del formulario
        $request->validate([
            'Nombre' => 'required',
            'Celular' => 'required',
            'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        //$datosEmpleado=request()->all();
        // Procesar los datos excepto _token 
        $datosEmpleado = $request->except('_token');

        // Verificar si hay un archivo de imagen
        if($request->hasFile('imagen')) {
            // Almacenar la imagen en la carpeta 'imagenes' dentro de 'public/storage'
            $datosEmpleado['imagen'] = $request->file('imagen')->store('imagenes', 'public');
        }

        // Crear el nuevo registro en la base de datos
        Empleado::create($datosEmpleado);

        // Redirigir a la lista de empleados
        return redirect()->route('empleado.index')->with('success', 'Registro Exitoso');

        //Empleado::insert($datosEmpleado);
        //return response()->json($datosEmpleado);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function show(Empleado $empleado)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $empleado=Empleado::findOrFail($id);
        return view('empleado.edit',compact('empleado'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Validar los datos del formulario
        $request->validate([
            'Nombre' => 'required',
            'Celular' => 'required',
            'imagen' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Procesar los datos excepto _token y _method
        $datosEmpleado = $request->except(['_token', '_method']);
        $empleado = Empleado::findOrFail($id);

        // Verificar si se ha subido una nueva imagen
        if ($request->hasFile('imagen')) {
            // Eliminar la imagen anterior si existe
            if ($empleado->imagen) {
            \Storage::delete('public/' . $empleado->imagen);
            }

            // Almacenar la nueva imagen
            $datosEmpleado['imagen'] = $request->file('imagen')->store('imagenes', 'public');
        }

        // Actualizar los datos del empleado
        $empleado->update($datosEmpleado);

        // Redirigir a la lista de empleados
        return redirect()->route('empleado.index')->with('success','Actualizacion exitosa');

        //Empleado::where('id','=',$id)->update($datosEmpleado);
        
        //return view('empleado.edit', compact('empleado'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        Empleado::destroy($id);

        return redirect()->route('empleado.index')->with('success','Eliminado Correctamente');
    }
}
