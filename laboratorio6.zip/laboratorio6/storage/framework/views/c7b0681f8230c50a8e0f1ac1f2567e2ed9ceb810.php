

<?php $__env->startSection('content'); ?>
<div class="container">

<h1 class="my-4"> Registro de Empleados </h1>

<a href="<?php echo e(url('/empleado/')); ?>" class="btn btn-secondary mb-3">Regresar</a>

<form action="<?php echo e(url('/empleado')); ?>" method="post" enctype="multipart/form-data"> 

	<?php echo csrf_field(); ?>

	<div class="form-group">
		<label for="Nombre">Nombre del Empleado</label>
		<input type="text" class="form-control" id="Nombre" name="Nombre" placeholder="Escriba su Nombre Completo" required>
	</div>
	
	<div class="form-group">
		<label for="Celular">Celular del Empleado</label>
		<input type="number" class="form-control" id="Celular" name="Celular" placeholder="Numero de Celular" required>
	</div>

	<div class="form-group">
		<label for="imagen">Imagen del Empleado</label>
		<input type="file" class="form-control-file" id="imagen" name="imagen" accept="image/*">	
	</div>

	<button type="submit" class="btn btn-primary">Registrar</button> 
	
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laboratorio6\resources\views/empleado/create.blade.php ENDPATH**/ ?>