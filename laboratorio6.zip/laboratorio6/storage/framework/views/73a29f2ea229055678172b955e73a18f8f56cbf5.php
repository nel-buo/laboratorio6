

<?php $__env->startSection('content'); ?>
<div class="container">

<h1 class="my-4"> Modificar Empleado </h1>

<form action="<?php echo e(url('/empleado/' . $empleado->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    
    <div class="form-group">
        <label for="Nombre">Nombre del Empleado</label>
        <input type="text" class="form-control" id="Nombre" name="Nombre" placeholder="Escriba su Nombre Completo" value="<?php echo e($empleado->Nombre); ?>" required> 
    </div>

    <div class="form-group">
        <label for="Celular">Celular del Empleado</label>
        <input type="number" class="form-control" id="Celular" name="Celular" placeholder="Número de Celular" value="<?php echo e($empleado->Celular); ?>" required>
    </div>

    <div class="form-group">
        <label for="imagen">Imagen del Empleado</label>
        <input type="file" class="form-control-file" id="imagen" name="imagen" accept="image/*">
    </div>

    <?php if($empleado->imagen): ?>
        <div class="my-3">
            <img src="<?php echo e(asset('storage/' . $empleado->imagen)); ?>" alt="Imagen del Empleado" class="img-thumbnail" style="max-width: 200px;">
        </div>
    <?php else: ?>
        <p>No hay imagen</p>
    <?php endif; ?>

    <button type="submit" class="btn btn-primary">Modificar</button> 

</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laboratorio6\resources\views/empleado/edit.blade.php ENDPATH**/ ?>