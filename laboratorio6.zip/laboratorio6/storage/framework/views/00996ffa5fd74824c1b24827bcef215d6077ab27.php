

<?php $__env->startSection('content'); ?>
<div class="container">

<h1>Lista de Empleados</h1>

<a href="<?php echo e(url('empleado/create')); ?>" class="btn btn-primary">Registrar Nuevo Empleado</a>

<?php if(Session::has('success')): ?>
	<div class="alert alert-success">
		<?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?> 

<table class="table table-bordered table-hover">
	<thead class="thead-dark">
	<tr>
		<th>#</th>
		<th>Nombre</th>
		<th>Celular</th>
		<th>Imagen</th>
		<th colspan="2" class="text-center">Acciones</th>
	</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<tr>
			<td><?php echo e($empleado->id); ?></td>
			<td><?php echo e($empleado->Nombre); ?></td>
			<td><?php echo e($empleado->Celular); ?></td>
		
			<td>
				<?php if($empleado->imagen): ?>
					<img src="<?php echo e(asset('storage/' . $empleado->imagen)); ?>" alt= "Imagen del Empleado" class="img-thumbnail" style="max-width: 50px;">
				<?php else: ?>
					<p>No hay Imagen</p>
				<?php endif; ?>
			</td>

			<td class="text-center">
				<form method="post" action="<?php echo e(url('/empleado/'.$empleado->id)); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('DELETE'); ?>
					<input type="submit" onclick="return confirm('¿Desea eliminar al empleado?')" value="Borrar" class="btn btn-danger btn-sm"> 
				</form>
			</td>
		
			<td>
				<a href="<?php echo e(url('/empleado/'. $empleado->id . '/edit')); ?>" class="btn btn-warning btn-sm">Modificar</a>
			</td>
		</tr>
	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>

</table> 

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laboratorio6\resources\views/empleado/index.blade.php ENDPATH**/ ?>