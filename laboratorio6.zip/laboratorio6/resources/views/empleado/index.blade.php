@extends('layouts.app')

@section('content')
<div class="container">

<h1>Lista de Empleados</h1>

<a href="{{url('empleado/create')}}" class="btn btn-primary">Registrar Nuevo Empleado</a>

@if (Session::has('success'))
	<div class="alert alert-success">
		{{Session::get('success')}}
	</div>
@endif 

<table class="table table-bordered table-hover">
	<thead class="thead-dark">
	<tr>
		<th>#</th>
		<th>Nombre</th>
		<th>Celular</th>
		<th>Imagen</th>
		<th colspan="2" class="text-center">Acciones</th>
	</tr>
	</thead>

	<tbody>
		@foreach($empleados as $empleado)

		<tr>
			<td>{{$empleado->id}}</td>
			<td>{{$empleado->Nombre}}</td>
			<td>{{$empleado->Celular}}</td>
		
			<td>
				@if ($empleado->imagen)
					<img src="{{ asset('storage/' . $empleado->imagen) }}" alt= "Imagen del Empleado" class="img-thumbnail" style="max-width: 50px;">
				@else
					<p>No hay Imagen</p>
				@endif
			</td>

			<td class="text-center">
				<form method="post" action="{{url('/empleado/'.$empleado->id)}}">
					@csrf
					@method('DELETE')
					<input type="submit" onclick="return confirm('¿Desea eliminar al empleado?')" value="Borrar" class="btn btn-danger btn-sm"> 
				</form>
			</td>
		
			<td>
				<a href="{{url('/empleado/'. $empleado->id . '/edit')}}" class="btn btn-warning btn-sm">Modificar</a>
			</td>
		</tr>
	
		@endforeach
	</tbody>

</table> 

</div>
@endsection
