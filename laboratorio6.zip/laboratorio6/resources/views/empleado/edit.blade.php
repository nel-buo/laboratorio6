@extends('layouts.app')

@section('content')
<div class="container">

<h1 class="my-4"> Modificar Empleado </h1>

<form action="{{ url('/empleado/' . $empleado->id) }}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PATCH')
    
    <div class="form-group">
        <label for="Nombre">Nombre del Empleado</label>
        <input type="text" class="form-control" id="Nombre" name="Nombre" placeholder="Escriba su Nombre Completo" value="{{ $empleado->Nombre }}" required> 
    </div>

    <div class="form-group">
        <label for="Celular">Celular del Empleado</label>
        <input type="number" class="form-control" id="Celular" name="Celular" placeholder="Número de Celular" value="{{ $empleado->Celular }}" required>
    </div>

    <div class="form-group">
        <label for="imagen">Imagen del Empleado</label>
        <input type="file" class="form-control-file" id="imagen" name="imagen" accept="image/*">
    </div>

    @if ($empleado->imagen)
        <div class="my-3">
            <img src="{{ asset('storage/' . $empleado->imagen) }}" alt="Imagen del Empleado" class="img-thumbnail" style="max-width: 200px;">
        </div>
    @else
        <p>No hay imagen</p>
    @endif

    <button type="submit" class="btn btn-primary">Modificar</button> 

</form>
</div>
@endsection
