@extends('layouts.app')

@section('content')
<div class="container">

<h1 class="my-4"> Registro de Empleados </h1>

<a href="{{url('/empleado/')}}" class="btn btn-secondary mb-3">Regresar</a>

<form action="{{ url('/empleado') }}" method="post" enctype="multipart/form-data"> {{-- Este atributo en el formulario es para permitir la carga de archivos. --}}

	@csrf

	<div class="form-group">
		<label for="Nombre">Nombre del Empleado</label>
		<input type="text" class="form-control" id="Nombre" name="Nombre" placeholder="Escriba su Nombre Completo" required>
	</div>
	
	<div class="form-group">
		<label for="Celular">Celular del Empleado</label>
		<input type="number" class="form-control" id="Celular" name="Celular" placeholder="Numero de Celular" required>
	</div>

	<div class="form-group">
		<label for="imagen">Imagen del Empleado</label>
		<input type="file" class="form-control-file" id="imagen" name="imagen" accept="image/*">	
	</div>

	<button type="submit" class="btn btn-primary">Registrar</button> 
	
</form>

</div>
@endsection
